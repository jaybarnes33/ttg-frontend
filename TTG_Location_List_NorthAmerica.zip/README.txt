TTG App – Full North America Location List

Includes:
- Coastal U.S. (East, West, Gulf)
- Great Lakes (U.S. and Canada where applicable)
- Mexico (Pacific, Gulf, Caribbean coasts)
- Caribbean islands (e.g., Puerto Rico, Bahamas, Jamaica)

Fields:
- name: Place name
- lat, lng: Coordinates
- type: boat_ramp, beach, pier, etc.
- region: Two- or three-letter code (e.g., FL, MX, CAR)

Use for in-app autocomplete only — no GPS or online lookups required.
